package com.example.greeneats.controller;

import com.example.greeneats.model.CartManager;
import com.example.greeneats.model.MenuItem;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class AddToCartController {

    @FXML
    private Label itemNameLabel;

    @FXML
    private Label itemPriceLabel;

    @FXML
    private TextField quantityField;

    private MenuItem menuItem;
    private GreenEatsController parentController; // Reference to parent controller

    public void setMenuItem(MenuItem item) {
        this.menuItem = item;
        itemNameLabel.setText(item.getName());
        itemPriceLabel.setText(String.format("₱%.2f", item.getPrice()));
        quantityField.setText("1");
    }

    // Method to set reference to parent controller for cart updates
    public void setParentController(GreenEatsController parentController) {
        this.parentController = parentController;
    }

    @FXML
    private void onAddToCartClicked() {
        int quantity;
        try {
            quantity = Integer.parseInt(quantityField.getText());
            if (quantity <= 0) quantity = 1;
        } catch (NumberFormatException e) {
            quantity = 1;
        }

        if (menuItem != null) {
            CartManager.getCart().addItem(menuItem, quantity);
            System.out.println("Added to cart: " + menuItem.getName() + " x" + quantity);

            // Update cart summary in parent controller if available
            if (parentController != null) {
                parentController.updateCartSummaryUI();
            }
        }

        closeWindow();
    }

    @FXML
    private void onCancelClicked() {
        closeWindow();
    }

    @FXML
    private void onAddQuantityClicked() {
        try {
            int qty = Integer.parseInt(quantityField.getText());
            quantityField.setText(String.valueOf(qty + 1));
        } catch (NumberFormatException e) {
            quantityField.setText("1");
        }
    }

    @FXML
    private void onSubtractQuantityClicked() {
        try {
            int qty = Integer.parseInt(quantityField.getText());
            if (qty > 1) {
                quantityField.setText(String.valueOf(qty - 1));
            }
        } catch (NumberFormatException e) {
            quantityField.setText("1");
        }
    }

    // Removed duplicate onDecreaseQuantityClicked method as it's the same as onSubtractQuantityClicked

    private void closeWindow() {
        Stage stage = (Stage) itemNameLabel.getScene().getWindow();
        stage.close();
    }
}