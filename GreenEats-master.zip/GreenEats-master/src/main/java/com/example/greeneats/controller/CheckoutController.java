package com.example.greeneats.controller;

import com.example.greeneats.model.CartItem;
import com.example.greeneats.model.CartManager;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.stage.Stage;

public class CheckoutController {

    @FXML
    private TableColumn<CartItem, String> itemColumn;
    @FXML
    private TableColumn<CartItem, Integer> quantityColumn;
    @FXML
    private TableColumn<CartItem, String> priceColumn;
    @FXML
    private TableColumn<CartItem, Double> caloriesColumn;
    @FXML
    private TableView<CartItem> checkoutTable;

    @FXML
    public void initialize() {
        itemColumn.setCellValueFactory(cellData ->
                new SimpleStringProperty(cellData.getValue().getMenuItem().getName()));
        quantityColumn.setCellValueFactory(cellData ->
                new SimpleIntegerProperty(cellData.getValue().getQuantity()).asObject());
        priceColumn.setCellValueFactory(cellData ->
                new SimpleStringProperty(cellData.getValue().getFormattedPrice()));
        caloriesColumn.setCellValueFactory(cellData ->
                new SimpleDoubleProperty(cellData.getValue().getMenuItem().getCalories()).asObject());

        checkoutTable.setItems(FXCollections.observableArrayList(CartManager.getCart().getItems()));
    }

    @FXML
    private void onConfirmCheckoutClicked() {
        System.out.println("Order confirmed: " + CartManager.getCart());
        CartManager.clearCart();
        checkoutTable.getItems().clear();
        ((Stage) checkoutTable.getScene().getWindow()).close();
    }

    @FXML
    private void onCancelCheckoutClicked() {
        ((Stage) checkoutTable.getScene().getWindow()).close();
    }
}
