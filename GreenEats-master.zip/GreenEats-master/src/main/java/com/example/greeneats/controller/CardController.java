package com.example.greeneats.controller;

import com.example.greeneats.model.MenuItem;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import java.io.IOException;

public class CardController {
    @FXML
    private Label nameLabel;
    @FXML
    private Label descLabel;
    @FXML
    private Label priceLabel;
    @FXML
    private ImageView imageView;
    @FXML
    private Button addToCartButton;

    public void setData(MenuItem item) {
        nameLabel.setText(item.getName());
        descLabel.setText(item.getDescription());
        priceLabel.setText(item.getFormattedPrice());

        addToCartButton.setOnAction(event -> {
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/greeneats/AddToCart.fxml"));
                Parent root = loader.load();

                AddToCartController controller = loader.getController();
                controller.setMenuItem(item);

                Stage popupStage = new Stage();
                popupStage.setTitle("Add to Cart");
                popupStage.setScene(new Scene(root));
                popupStage.setResizable(false);
                popupStage.showAndWait();
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
    }
}
