package com.example.greeneats.view;

public class CartView {
}
