package com.example.greeneats.config;

public final class AppConfig {
    public static final String BELGIAN_MENU_PATH = "menu/belgian.csv";

    public static final String CSS_PATH = "/styles.css";
}
