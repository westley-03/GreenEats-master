package com.example.greeneats.view;

public class MenuView {



}
