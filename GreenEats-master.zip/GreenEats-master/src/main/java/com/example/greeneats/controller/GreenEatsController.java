package com.example.greeneats.controller;

import com.example.greeneats.GreenEatsApp;
import com.example.greeneats.model.MenuItem;
import com.example.greeneats.user.UserSession;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.chart.PieChart;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.Parent;
import javafx.event.ActionEvent;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import static com.example.greeneats.user.LoginController.showAlert;

public class GreenEatsController implements Initializable {
    @FXML
    private BorderPane borderPane;
    @FXML
    private StackPane stackPane;
    @FXML
    private ScrollPane contentPane;
    @FXML
    private PieChart pieChart;
    @FXML
    private AnchorPane anchorPane;
    @FXML
    private VBox vBox;

    // SignIn Page
    @FXML
    private TextField usernameField;
    @FXML
    private TextField passwordField;

    // SignUp Page
    @FXML
    private TextField firstNameField;
    @FXML
    private TextField lastNameField;

    // Sidebar buttons
    @FXML
    private Button homeButton;
    @FXML
    private Button findButton; // (Optional: Can be removed later if unused)
    @FXML
    private Button cuisinesButton;
    @FXML
    private Button nutritionButton;
    @FXML
    private Button settingsButton;
    @FXML
    private Button exitButton;

    // Cart UI Elements
    @FXML
    private Label cartItemCountLabel;
    @FXML
    private Label cartTotalLabel;

    // Dashboard Elements
    @FXML
    private PieChart dietChart;

    @FXML
    private TableView<?> nutritionTable;

    @FXML
    private TableColumn<?, ?> sourceColumn;

    @FXML
    private TableColumn<?, ?> nutritionalValueColumn;

    @FXML
    private TableColumn<?, ?> priceColumn1;

    @FXML
    private HBox cartSummaryBox;

    // Sidebar
    private BorderPane sidebarPane;
    private Button activeButton;

    @FXML
    private VBox menuContainer;
    @FXML
    private GridPane grid;

    // Menu items
    private final List<MenuItem> menuItems = new ArrayList<>();

    // ====== Preference (Image Filter) Fields ======
    @FXML private StackPane chickenPane;
    @FXML private StackPane pizzaPane;
    @FXML private StackPane coffeePane;
    @FXML private StackPane burgersPane;

    private final List<String> selectedCategories = new ArrayList<>();

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // Pie chart example (optional)
        if (pieChart != null) {
            ObservableList<PieChart.Data> pieChartData =
                    FXCollections.observableArrayList(
                            new PieChart.Data("Chicken", 14),
                            new PieChart.Data("Pizza", 14),
                            new PieChart.Data("Beef", 20),
                            new PieChart.Data("Salads", 50)
                    );
            pieChart.setData(pieChartData);
            pieChart.setTitle("Food Distribution");
        }

        // Initialize cart summary UI
        updateCartSummaryUI();

        // Initialize dashboard elements if they exist
        initializeDashboard();
    }

    public void postInitialize() {
        loadTestMenuItems();
        try {
            populateGrid();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void loadTestMenuItems() {
        menuItems.clear();
        menuItems.add(new MenuItem(
                "Chicken",
                150.0,
                "Crispy fried chicken",
                500,
                "Best Sellers",
                "/image/bowld/2pc_chicken.jpg"
        ));
        menuItems.add(new MenuItem(
                "Salad",
                120.0,
                "Fresh veggie salad",
                200,
                "Healthy Options",
                "/image/lettuce.jpg"
        ));
    }

    private void populateGrid() throws IOException {
        grid.getChildren().clear();
        int column = 0;
        int row = 0;

        for (MenuItem item : menuItems) {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/greeneats/MenuItemCard.fxml"));
            StackPane card = loader.load();

            CardController controller = loader.getController();
            controller.setData(item);

            grid.add(card, column, row);
            column++;
            if (column == 3) {
                column = 0;
                row++;
            }
        }
    }

    // Logout button
    @FXML
    protected void onLogOutClick(ActionEvent event) throws IOException {
        UserSession.getInstance().logout();
        try {
            Parent loginScreen = FXMLLoader.load(getClass().getResource("/com/example/greeneats/LogInPage.fxml"));
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.getScene().setRoot(loginScreen);
        } catch (IOException e) {
            showAlert("Error loading login screen: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public void setContent(Parent pane) {
        contentPane.setContent(pane);
    }

    @FXML
    protected void onExitClicked(ActionEvent event) {
        Platform.exit();
    }

    @FXML
    protected void onHomeClicked(ActionEvent event) throws IOException {
        Parent pane = FXMLLoader.load(getClass().getResource("/com/example/greeneats/HomePage.fxml"));
        contentPane.setContent(pane);
        setActiveButton((Button) event.getSource());
    }

    // ====== Preference Page Loader ======
    @FXML
    protected void onPreferenceClicked(ActionEvent event) throws IOException {
        Parent pane = FXMLLoader.load(getClass().getResource("/com/example/greeneats/Preference.fxml"));
        contentPane.setContent(pane);
        setActiveButton((Button) event.getSource());
    }

    @FXML
    protected void onCuisinesClicked(ActionEvent event) throws IOException {
        Parent pane = FXMLLoader.load(getClass().getResource("/com/example/greeneats/Resto.fxml"));
        contentPane.setContent(pane);
        setActiveButton((Button) event.getSource());
    }

    @FXML
    protected void onRestoClicked(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/greeneats/Menu.fxml"));
        Parent pane = loader.load();

        GreenEatsController controller = loader.getController();
        controller.postInitialize();

        ScrollPane scrollPane = (ScrollPane) ((Node) event.getSource()).getScene().lookup("#contentPane");
        if (scrollPane != null) {
            scrollPane.setContent(pane);
        }
    }

    @FXML
    protected void addToCartClicked(ActionEvent event) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(GreenEatsApp.class.getResource("AddToCart.fxml"));
        Parent root = fxmlLoader.load();

        // Get the controller and set parent reference
        AddToCartController addToCartController = fxmlLoader.getController();
        addToCartController.setParentController(this);

        Stage popupStage = new Stage();
        popupStage.setTitle("Add to Cart");
        popupStage.setScene(new Scene(root));
        popupStage.setResizable(false);
        popupStage.showAndWait();

        // Update cart summary after adding item (this will also be called from AddToCartController)
        updateCartSummaryUI();
    }

    // Called when the cart icon is clicked
    @FXML
    private void goToCheckout(MouseEvent event) {
        try {
            Parent checkoutRoot = FXMLLoader.load(getClass().getResource("/com/example/greeneats/view/Checkout.fxml"));
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(checkoutRoot));
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    protected void onCartClicked(ActionEvent event) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(GreenEatsApp.class.getResource("CheckOutPage.fxml"));
        Parent root = fxmlLoader.load();

        Stage popupStage = new Stage();
        popupStage.setTitle("Check out");
        popupStage.setScene(new Scene(root));
        popupStage.setResizable(false);
        popupStage.showAndWait();

        // Update cart summary after checkout
        updateCartSummaryUI();
    }

    // Utility method to update cart summary in UI
    public void updateCartSummaryUI() {
        // Note: You'll need to implement CartManager class or replace with your cart logic
        // For now, using placeholder logic - replace with your actual cart implementation
        if (cartItemCountLabel != null && cartTotalLabel != null) {
            // Replace these with actual cart data retrieval
            // int itemCount = CartManager.getCart().getTotalItemCount();
            // double totalPrice = CartManager.getCart().getTotalPrice();

            // Placeholder values - replace with actual cart data
            int itemCount = 0; // Replace with actual cart item count
            double totalPrice = 0.0; // Replace with actual cart total

            cartItemCountLabel.setText(itemCount + " item" + (itemCount == 1 ? "" : "s"));
            cartTotalLabel.setText(String.format("₱%.2f", totalPrice));
        }
    }

    @FXML
    private void onHelpClicked() {
        showInfoWindow("Help", "How to use the GreenEats App",
                "1. Browse restaurants on the main screen.\n" +
                        "2. Click a restaurant card to view details.\n" +
                        "3. Use filters and search for specific cuisines.\n" +
                        "4. Check the status (OPEN/CLOSED) before visiting.\n" +
                        "5. Access Settings > Help anytime for guidance.");
    }

    @FXML
    private void onProjectDescriptionClicked() {
        showInfoWindow("Project Description", "About GreenEats",
                "GreenEats is a restaurant discovery app for DLSU students and staff.\n\n" +
                        "Features:\n" +
                        "- Curated list of nearby restaurants\n" +
                        "- Visual cards with live status\n" +
                        "- Simple, intuitive UI with FXML and JavaFX\n\n" +
                        "Developed for our LBYCPEI Project.");
    }

    // Helper method to show new window
    private void showInfoWindow(String title, String header, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(header);
        alert.setContentText(content);
        alert.showAndWait();
    }

    @FXML
    protected void onNutritionTrackerClicked(ActionEvent event) throws IOException {
        Parent pane = FXMLLoader.load(getClass().getResource("/com/example/greeneats/DashBoard.fxml"));
        contentPane.setContent(pane);
        setActiveButton((Button) event.getSource());
    }

    // Initialize dashboard elements
    private void initializeDashboard() {
        if (dietChart != null) {
            ObservableList<PieChart.Data> pieChartData = FXCollections.observableArrayList(
                    new PieChart.Data("Protein", 25),
                    new PieChart.Data("Carbs", 45),
                    new PieChart.Data("Fats", 20),
                    new PieChart.Data("Fiber", 10)
            );
            dietChart.setData(pieChartData);
            dietChart.setTitle("Diet Distribution");
        }
    }

    @FXML
    protected void onSettingsClicked(ActionEvent event) throws IOException {
        Parent pane = FXMLLoader.load(getClass().getResource("/com/example/greeneats/Settings.fxml"));
        contentPane.setContent(pane);
        setActiveButton((Button) event.getSource());
    }

    // ====== Category Selection Logic ======
    @FXML
    private void onCategoryClicked(javafx.scene.input.MouseEvent event) {
        StackPane clickedPane = (StackPane) event.getSource();
        String category = "";

        if (clickedPane == chickenPane) category = "Chicken";
        else if (clickedPane == pizzaPane) category = "Pizza";
        else if (clickedPane == coffeePane) category = "Coffee / Milk Tea";
        else if (clickedPane == burgersPane) category = "Burgers";

        if (selectedCategories.contains(category)) {
            selectedCategories.remove(category);
            clickedPane.setStyle(""); // remove highlight
        } else {
            selectedCategories.add(category);
            clickedPane.setStyle("-fx-border-color: #10b981; -fx-border-width: 3; -fx-border-radius: 10;");
        }
    }

    @FXML
    private void onApplyPreferenceFilter() {
        System.out.println("Selected categories: " + selectedCategories);
        // TODO: Filter Resto.fxml grid using selectedCategories
    }

    @FXML
    private void onClearPreferenceFilter() {
        selectedCategories.clear();
        chickenPane.setStyle("");
        pizzaPane.setStyle("");
        coffeePane.setStyle("");
        burgersPane.setStyle("");
    }

    private void setActiveButton(Button clickedButton) {
        if (homeButton != null) {
            homeButton.getStyleClass().removeAll("nav-button-active");
            if (!homeButton.getStyleClass().contains("nav-button")) {
                homeButton.getStyleClass().add("nav-button");
            }
        }
        if (findButton != null) {
            findButton.getStyleClass().removeAll("nav-button-active");
            if (!findButton.getStyleClass().contains("nav-button")) {
                findButton.getStyleClass().add("nav-button");
            }
        }
        if (cuisinesButton != null) {
            cuisinesButton.getStyleClass().removeAll("nav-button-active");
            if (!cuisinesButton.getStyleClass().contains("nav-button")) {
                cuisinesButton.getStyleClass().add("nav-button");
            }
        }
        if (nutritionButton != null) {
            nutritionButton.getStyleClass().removeAll("nav-button-active");
            if (!nutritionButton.getStyleClass().contains("nav-button")) {
                nutritionButton.getStyleClass().add("nav-button");
            }
        }
        if (settingsButton != null) {
            settingsButton.getStyleClass().removeAll("nav-button-active");
            if (!settingsButton.getStyleClass().contains("nav-button")) {
                settingsButton.getStyleClass().add("nav-button");
            }
        }

        activeButton = clickedButton;
        if (activeButton != null) {
            activeButton.getStyleClass().removeAll("nav-button");
            activeButton.getStyleClass().add("nav-button-active");
        }
    }
}